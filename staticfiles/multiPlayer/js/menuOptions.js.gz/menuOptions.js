// Main function 
jQuery(document).ready(function(){
    
    jQuery("#host-game").click(function(){
        console.log("host game");
    });
    jQuery("#join-game").click(function(){
        console.log("join game");
    });
    jQuery("#how-to-play").click(function(){
        console.log("how to play");
    });

});

